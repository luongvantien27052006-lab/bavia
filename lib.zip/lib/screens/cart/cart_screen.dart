// ============================================================
//  FLUTTER
//  lib/screens/cart/cart_screen.dart
//  >> CHEP DE (khoa nut Thanh toan khi dong cua)
// ============================================================

// ============================================================
//  FLUTTER
//  lib/screens/cart/cart_screen.dart
//  >> CHEP DE (chan dat don: chua dang nhap -> mo login truoc)
// ============================================================

// ==================================================================
//  FLUTTER APP  (package bavia)
//  Dat tai:  lib/screens/cart/cart_screen.dart
//  >> CHEP DE (thay file co san)
// ==================================================================

// lib/screens/cart/cart_screen.dart
//
// Giỏ hàng: sửa số lượng từng món, nhập/áp mã voucher (gọi /vouchers/validate),
// xem tạm tính - giảm - tổng. Nút "Thanh toán" sang màn Checkout.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../widgets/glass_card.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../providers/cart_provider.dart';
import '../../providers/checkout_provider.dart';
import '../../utils/formatters.dart';
import '../../widgets/product_image.dart';
import '../../widgets/empty_state.dart';
import '../../providers/menu_provider.dart';
import '../product/product_detail_screen.dart';
import '../../models/product.dart';
import '../checkout/checkout_screen.dart';
import '../auth/login_screen.dart';
import '../../providers/auth_provider.dart';
import '../../providers/store_provider.dart';

class CartScreen extends ConsumerStatefulWidget {
  const CartScreen({super.key});

  @override
  ConsumerState<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends ConsumerState<CartScreen> {
  @override
  Widget build(BuildContext context) {
    final cart = ref.watch(cartProvider);
    final subtotal = ref.watch(cartSubtotalProvider);
    final discount = ref.watch(checkoutDiscountProvider);
    final total = ref.watch(checkoutTotalProvider);

    return Scaffold(
      backgroundColor:
          AppColors.dark ? const Color(0xFF1E1510) : const Color(0xFFFFEEDD),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Giỏ hàng',
            style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: GlassBackground(
        child: cart.isEmpty ? _emptyView() : _content(cart),
      ),
      bottomNavigationBar: cart.isEmpty
          ? null
          : _bottomBar(subtotal, discount, total),
    );
  }

  Widget _emptyView() {
    return EmptyState(
      icon: Icons.shopping_cart_outlined,
      title: 'Giỏ hàng đang trống',
      subtitle: 'Thêm vài món ngon để bắt đầu đơn hàng nhé!',
      actionLabel: 'Xem thực đơn',
      onAction: () => Navigator.of(context).maybePop(),
    );
  }

  Widget _content(List<CartItem> cart) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ...cart.map(_cartTile),
        const SizedBox(height: 8),
        Row(
          children: [
            Icon(Icons.local_offer_outlined,
                size: 16, color: AppColors.textMuted),
            const SizedBox(width: 6),
            Text('Mã giảm giá & điểm thưởng áp ở bước Thanh toán',
                style: TextStyle(
                    color: AppColors.textMuted.withOpacity(0.9),
                    fontSize: 12)),
          ],
        ),
        _suggestions(cart),
      ],
    );
  }

  /// #1 Gợi ý món ăn kèm (tăng giá trị đơn) — món chưa có trong giỏ.
  Widget _suggestions(List<CartItem> cart) {
    final inCart = cart.map((c) => c.product.id).toSet();
    final async = ref.watch(productsProvider);
    return async.maybeWhen(
      data: (all) {
        final sugg =
            all.where((p) => !inCart.contains(p.id)).take(8).toList();
        if (sugg.isEmpty) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 22),
            Text('Thêm bánh nhé? 🥐',
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                    color: AppColors.textDark)),
            const SizedBox(height: 2),
            Text('Gợi ý món ngon ăn kèm',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
            const SizedBox(height: 12),
            SizedBox(
              height: 172,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: sugg.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) => _suggCard(sugg[i]),
              ),
            ),
          ],
        );
      },
      orElse: () => const SizedBox.shrink(),
    );
  }

  Widget _suggCard(Product p) {
    return SizedBox(
      width: 132,
      child: GlassCard(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
              builder: (_) => ProductDetailScreen(product: p)),
        ),
        radius: 16,
        blur: 0,
        padding: EdgeInsets.zero,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(16)),
              child: AspectRatio(
                  aspectRatio: 1.3, child: ProductImage(product: p)),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                          color: AppColors.textDark)),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(Formatters.money(p.price),
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: AppColors.coffee,
                                fontWeight: FontWeight.w800,
                                fontSize: 12.5)),
                      ),
                      GestureDetector(
                        onTap: () {
                          HapticFeedback.lightImpact();
                          ref.read(cartProvider.notifier).add(p);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Đã thêm ${p.name}'),
                              duration: const Duration(milliseconds: 900),
                            ),
                          );
                        },
                        child: Container(
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(
                            color: AppColors.coffee,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.add,
                              color: Colors.white, size: 16),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cartTile(CartItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.dark
            ? Colors.white.withOpacity(0.06)
            : Colors.white.withOpacity(0.55),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: AppColors.dark
                ? Colors.white.withOpacity(0.12)
                : Colors.white.withOpacity(0.70)),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              width: 64,
              height: 64,
              child: ProductImage(product: item.product),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.product.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                if (item.options.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(item.optionsLabel,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: AppColors.coffee, fontSize: 12)),
                ],
                const SizedBox(height: 4),
                Text(Formatters.money(item.unitPrice),
                    style: TextStyle(
                        color: AppColors.textMuted, fontSize: 13)),
              ],
            ),
          ),
          _qtyControls(item),
        ],
      ),
    );
  }

  Widget _qtyControls(CartItem item) {
    final notifier = ref.read(cartProvider.notifier);
    return Row(
      children: [
        _circleBtn(Icons.remove_rounded,
            () => notifier.decrementLine(item.lineId)),
        SizedBox(
          width: 32,
          child: Text('${item.quantity}',
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
        _circleBtn(
            Icons.add_rounded, () => notifier.incrementLine(item.lineId)),
      ],
    );
  }

  Widget _circleBtn(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: AppColors.coffee.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, size: 18, color: AppColors.coffee),
      ),
    );
  }

  Widget _bottomBar(int subtotal, int discount, int total) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        decoration: BoxDecoration(
          color: AppColors.dark
              ? const Color(0xFF221A15).withOpacity(0.92)
              : Colors.white.withOpacity(0.85),
          border: Border(
              top: BorderSide(
                  color: AppColors.dark
                      ? Colors.white.withOpacity(0.10)
                      : Colors.white.withOpacity(0.70))),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(AppColors.dark ? 0.3 : 0.06),
                blurRadius: 14,
                offset: const Offset(0, -2)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _summaryRow('Tạm tính', subtotal),
            if (discount > 0) _summaryRow('Giảm giá', -discount),
            const Divider(height: 18),
            _summaryRow('Tổng cộng', total, bold: true),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: !_storeOpen(ref)
                  ? null
                  : () async {
                // Chưa đăng nhập -> mở màn đăng nhập trước khi thanh toán.
                if (ref.read(authProvider).user == null) {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  );
                  if (!mounted) return;
                  if (ref.read(authProvider).user == null) return;
                }
                if (!mounted) return;
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const CheckoutScreen()),
                );
              },
              child: Text(
                  _storeOpen(ref) ? 'Thanh toán' : 'Quán đang đóng cửa'),
            ),
          ],
        ),
      ),
    );
  }

  bool _storeOpen(WidgetRef ref) => ref
      .watch(storeStatusProvider)
      .maybeWhen(data: (s) => s.isOpen, orElse: () => true);

  Widget _summaryRow(String label, int amount, {bool bold = false}) {
    final style = TextStyle(
      fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
      fontSize: bold ? 17 : 14,
      color: bold ? AppColors.coffee : AppColors.textDark,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: style),
          Text(
            '${amount < 0 ? '−' : ''}${Formatters.money(amount.abs())}',
            style: style,
          ),
        ],
      ),
    );
  }
}